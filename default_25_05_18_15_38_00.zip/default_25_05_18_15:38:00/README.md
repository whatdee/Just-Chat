# Make It Meme

Join the fun with MakeItMeme.com, a multiplayer chat game where memes and friends come together!

## Features
- Login with Google or play as an anonymous guest
- Create and join chat lobbies
- Send and receive real-time chat messages
- Add or remove friends, see who is online
- Mute/unmute chat sounds and background music
- Language filters for lobbies
- Emoji reactions to messages
- Fun onboarding experiences

## Setup Firebase Project
1. Go to [Firebase Console](https://console.firebase.google.com/).
2. Create a new project.
3. Enable Firestore and Authentication for Google Sign-In.
4. Copy your Firebase configuration into `src/firebaseConfig.js`.

## Local Development
1. Clone the repo:
   