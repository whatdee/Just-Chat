import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Auth from './components/Auth';
import LobbyList from './components/LobbyList';
import Lobby from './components/Lobby';
import Onboarding from './components/Onboarding';
import firebase from './firebaseConfig';

const App = () => {
    const [user, setUser] = useState(null);
    const [friendList, setFriendList] = useState([]);

    useEffect(() => {
        firebase.auth().onAuthStateChanged(setUser);
        if (user) {
            const friendRef = firebase.database().ref(`users/${user.uid}/friends`);
            friendRef.on('value', snapshot => {
                const friends = snapshot.val() || {};
                setFriendList(Object.values(friends));
            });
        }
    }, [user]);

    return (
        <Router>
            <Switch>
                <Route path="/" exact component={user ? LobbyList : Onboarding} />
                <Route path="/login" component={Auth} />
                <Route path="/lobby/:id" component={Lobby} />
            </Switch>
        </Router>
    );
};

export default App;
