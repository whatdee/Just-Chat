import React, { useState } from 'react';
import firebase from '../firebaseConfig';

const Auth = () => {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const loginWithGoogle = async () => {
        setLoading(true);
        try {
            const provider = new firebase.auth.GoogleAuthProvider();
            await firebase.auth().signInWithPopup(provider);
        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    const loginAsGuest = async () => {
        setLoading(true);
        try {
            await firebase.auth().signInAnonymously();
        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div>
            <h1>Make It Meme</h1>
            <button onClick={loginWithGoogle} disabled={loading}>
                Login with Google
            </button>
            <button onClick={loginAsGuest} disabled={loading}>
                Play as Guest
            </button>
            {error && <p>{error}</p>}
        </div>
    );
};

export default Auth;
