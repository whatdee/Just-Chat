import React, { useEffect, useState } from 'react';
import firebase from '../firebaseConfig';
import ChatMessage from './ChatMessage';

const Lobby = ({ match }) => {
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');
    const [lobbyData, setLobbyData] = useState({});
    const user = firebase.auth().currentUser;

    useEffect(() => {
        const lobbyRef = firebase.database().ref(`lobbies/${match.params.id}`);
        lobbyRef.on('value', snapshot => {
            setLobbyData(snapshot.val());
        });

        const messageRef = firebase.database().ref(`lobbies/${match.params.id}/messages`);
        messageRef.on('value', snapshot => {
            const messagesData = snapshot.val() || {};
            setMessages(Object.entries(messagesData).map(([id, data]) => ({ id, ...data })));
        });
    }, [match.params.id]);

    const sendMessage = () => {
        if (newMessage.trim()) {
            const messageRef = firebase.database().ref(`lobbies/${match.params.id}/messages`);
            messageRef.push({
                text: newMessage,
                user: user.displayName || 'Guest',
                timestamp: firebase.database.ServerValue.TIMESTAMP
            });
            setNewMessage('');
        }
    };

    return (
        <div>
            <h1>{lobbyData.name}</h1>
            <div>
                {messages.map(msg => <ChatMessage key={msg.id} {...msg} />)}
            </div>
            <input value={newMessage} onChange={(e) => setNewMessage(e.target.value)} />
            <button onClick={sendMessage}>Send</button>
        </div>
    );
};

export default Lobby;
