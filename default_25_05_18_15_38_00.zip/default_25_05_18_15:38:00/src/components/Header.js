import React from 'react';
import firebase from '../firebaseConfig';

const Header = () => {
    const user = firebase.auth().currentUser;

    const logout = () => {
        firebase.auth().signOut();
    };

    return (
        <header>
            <h1>Make It Meme</h1>
            {user && (
                <div>
                    <span>{user.displayName || 'Guest'}</span>
                    <button onClick={logout}>Logout</button>
                </div>
            )}
        </header>
    );
};

export default Header;
