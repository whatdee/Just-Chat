import React, { useEffect, useState } from 'react';
import firebase from '../firebaseConfig';

const LobbyList = () => {
    const [lobbies, setLobbies] = useState([]);
    const [lobbyName, setLobbyName] = useState('');
    const user = firebase.auth().currentUser;

    useEffect(() => {
        const lobbyRef = firebase.database().ref('lobbies');
        lobbyRef.on('value', snapshot => {
            const lobbiesData = snapshot.val() || {};
            setLobbies(Object.entries(lobbiesData).map(([id, data]) => ({ id, ...data })));
        });
    }, []);

    const createLobby = () => {
        const lobbyRef = firebase.database().ref('lobbies');
        lobbyRef.push({
            name: lobbyName,
            members: { [user.uid]: true },
            owner: user.uid,
            maxPlayers: 20,
            language: 'English'
        });
        setLobbyName('');
    };

    return (
        <div>
            <h1>Lobby List</h1>
            <input value={lobbyName} onChange={(e) => setLobbyName(e.target.value)} placeholder="Lobby Name" />
            <button onClick={createLobby}>Create Lobby</button>
            <ul>
                {lobbies.map(lobby => (
                    <li key={lobby.id}>
                        <a href={`/lobby/${lobby.id}`}>{lobby.name}</a>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default LobbyList;
