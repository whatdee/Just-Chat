import React from 'react';

const ChatMessage = ({ text, user }) => {
    return (
        <div>
            <strong>{user}: </strong>
            <span>{text}</span>
        </div>
    );
};

export default ChatMessage;
