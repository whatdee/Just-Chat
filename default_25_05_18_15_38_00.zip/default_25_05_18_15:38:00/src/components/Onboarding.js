import React from 'react';

const Onboarding = () => {
    return (
        <div>
            <h1>Welcome to MakeItMeme!</h1>
            <p>Join the meme party and express yourself!</p>
            <img src="https://example.com/makeitmeme_logo.gif" alt="Make It Meme logo" />
        </div>
    );
};

export default Onboarding;
