import React, { useEffect, useState } from 'react';
import firebase from '../firebaseConfig';

const FriendList = () => {
    const [friends, setFriends] = useState([]);
    const user = firebase.auth().currentUser;

    useEffect(() => {
        const friendRef = firebase.database().ref(`users/${user.uid}/friends`);
        friendRef.on('value', snapshot => {
            const friendsData = snapshot.val() || {};
            setFriends(Object.entries(friendsData).map(([id, data]) => ({ id, ...data })));
        });
    }, [user]);

    return (
        <div>
            <h2>Your Friends</h2>
            <ul>
                {friends.map(friend => (
                    <li key={friend.id}>{friend.name} - {friend.online ? 'Online' : 'Offline'}</li>
                ))}
            </ul>
        </div>
    );
};

export default FriendList;
